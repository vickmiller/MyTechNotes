//
//  BViewController.h
//  RetainCycleDemo
//
//  Created by SamingZhong on 16/3/19.
//  Copyright © 2016年 SamingZhong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BViewController : UIViewController

@end
