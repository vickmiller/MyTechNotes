//
//  AppDelegate.h
//  RetainCycleDemo
//
//  Created by SamingZhong on 16/3/19.
//  Copyright © 2016年 SamingZhong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

