//
//  BViewController.m
//  RetainCycleDemo
//
//  Created by SamingZhong on 16/3/19.
//  Copyright © 2016年 SamingZhong. All rights reserved.
//

#import "BViewController.h"
#import "DataFetcher.h"
@interface BViewController ()
@property (strong, nonatomic) DataFetcher *dataFetcher;
@property (strong, nonatomic) NSData *data;
@end

@implementation BViewController{
    ///*__block*/ __weak BViewController* weakSelf;
}

- (void)viewDidLoad{
    NSLog(@"dataFetcher:%@", _dataFetcher);
}
- (IBAction)startTask:(id)sender {
    NSURL *url = [NSURL URLWithString:@"https://www.apple.com"];
    
    _dataFetcher = [[DataFetcher alloc]initWithURL:url];
    
    __weak typeof(self) weakSelf = self;
    [_dataFetcher startWithCompletionBlock:^(NSData *responseData) {
        NSLog(@"data.length:%ld",responseData.length);
        NSLog(@"weakSelf:%@", weakSelf);
        //NSLog(@"self:%@", weakSelf);
        //weakSelf.data = responseData;
        //self.data = responseData;
        //[weakSelf logAndDoSomething];
        //self.dataFetcher = nil;
    }];
}

- (void)logAndDoSomething{
    //NSLog(@"数据回来了，我是控制器。。data:%@",weakSelf.data);
}
- (void)dealloc{
    NSLog(@"%@,%s", self, __func__);
}

@end
