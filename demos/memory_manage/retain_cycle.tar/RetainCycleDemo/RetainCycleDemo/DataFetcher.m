//
//  DataFetcher.m
//  RetainCycleDemo
//
//  Created by SamingZhong on 16/3/19.
//  Copyright © 2016年 SamingZhong. All rights reserved.
//

#import "DataFetcher.h"
@interface DataFetcher ()
@property (strong, nonatomic) NSURL *url;
@property (copy, nonatomic) DataFetcherCompletionBlock completionBlock;
@property (strong, nonatomic) NSData *fetchedData;
@end

@implementation DataFetcher


- (instancetype)initWithURL:(NSURL *)url{
    self = [super init];
    if (self) {
        _url = url;
    }
    return self;
}
- (void)startWithCompletionBlock:(DataFetcherCompletionBlock)completion{
    self.completionBlock = completion;
    
    //do some asyn work...
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        _fetchedData = [NSData dataWithContentsOfURL:_url];
        NSLog(@"things downloading...");
        sleep(5);
        //things done,pass data to the block
        [self p_requestCompleted];
    });
    /*_fetchedData = [NSData dataWithContentsOfURL:_url];
    [self p_requestCompleted];*/

}

- (void)p_requestCompleted {
    NSLog(@"_completionBlock:%@", _completionBlock);
    _completionBlock?_completionBlock(_fetchedData):nil;
    //_completionBlock = nil;
}

- (void)dealloc{
    NSLog(@"%@ is gonging to dealloc", self);
}
@end
