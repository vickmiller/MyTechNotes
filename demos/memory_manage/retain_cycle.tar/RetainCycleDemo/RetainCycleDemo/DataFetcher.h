//
//  DataFetcher.h
//  RetainCycleDemo
//
//  Created by SamingZhong on 16/3/19.
//  Copyright © 2016年 SamingZhong. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^DataFetcherCompletionBlock)(NSData *data);

@interface DataFetcher : NSObject

- (instancetype)initWithURL:(NSURL *)url;
- (void)startWithCompletionBlock:(DataFetcherCompletionBlock)completion;
@end
